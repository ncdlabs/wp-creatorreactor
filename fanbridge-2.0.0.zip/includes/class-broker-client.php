<?php
/**
 * FanBridge OAuth Broker Client
 * Handles communication with the centralized OAuth broker
 *
 * @package FanBridge
 * @author  ncdLabs
 * @company ncdLabs
 */

namespace FanBridge;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Broker_Client {

	const REST_NAMESPACE            = 'fanbridge/v1';
	const REST_ROUTE_CONNECT       = '/broker-connect';
	const REST_ROUTE_DISCONNECT    = '/broker-disconnect';
	const REST_ROUTE_STATUS        = '/broker-status';
	const REST_ROUTE_CALLBACK      = '/broker-callback';

	const OPTION_JWT_TOKEN         = 'fanbridge_login_jwt_token';

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	public static function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE_CALLBACK,
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'handle_callback' ],
				'permission_callback' => '__return_true',
			]
		);
	}

	private static function get_broker_options() {
		return Admin_Settings::get_options();
	}

	public static function get_broker_url() {
		$opts = self::get_broker_options();
		return isset( $opts['broker_url'] ) ? rtrim( $opts['broker_url'], '/' ) : 'https://auth.ncdlabs.com';
	}

	public static function get_site_id() {
		$opts = self::get_broker_options();
		return isset( $opts['site_id'] ) ? $opts['site_id'] : null;
	}

	public static function get_jwt_token() {
		$opts = Admin_Settings::get_raw_options();
		if ( isset( $opts['jwt_token'] ) ) {
			if ( Admin_Settings::is_encrypted( $opts['jwt_token'] ) ) {
				return Admin_Settings::encrypt_sensitive_value( $opts['jwt_token'] );
			}
			return $opts['jwt_token'];
		}
		return null;
	}

	public static function get_fanvue_oauth_client_id() {
		$opts = self::get_broker_options();
		return isset( $opts['fanvue_oauth_client_id'] ) ? $opts['fanvue_oauth_client_id'] : null;
	}

	public static function get_fanvue_oauth_redirect_uri() {
		$opts = self::get_broker_options();
		return isset( $opts['fanvue_oauth_redirect_uri'] ) ? $opts['fanvue_oauth_redirect_uri'] : null;
	}

	public static function get_fanvue_oauth_scopes() {
		$opts = self::get_broker_options();
		return isset( $opts['fanvue_oauth_scopes'] ) ? $opts['fanvue_oauth_scopes'] : null;
	}

	public static function get_fanvue_api_version() {
		$opts = self::get_broker_options();
		return isset( $opts['fanvue_api_version'] ) ? $opts['fanvue_api_version'] : '2025-06-26';
	}

	public static function is_configured() {
		return ! empty( self::get_broker_url() ) && ! empty( self::get_site_id() );
	}

	public static function is_connected() {
		$opts = Admin_Settings::get_raw_options();
		return ! empty( $opts['jwt_token'] );
	}

	public static function get_connect_url() {
		$site_id = self::get_site_id();
		if ( ! $site_id ) {
			return null;
		}

		$params = [
			'site_id' => $site_id,
		];

		$client_id = self::get_fanvue_oauth_client_id();
		if ( ! empty( $client_id ) ) {
			$params['client_id'] = $client_id;
		}

		$redirect_uri = self::get_fanvue_oauth_redirect_uri();
		if ( ! empty( $redirect_uri ) ) {
			$params['redirect_uri'] = $redirect_uri;
		}

		$scopes = self::get_fanvue_oauth_scopes();
		if ( ! empty( $scopes ) ) {
			$params['scope'] = $scopes;
		}

		return add_query_arg( $params, self::get_broker_url() . '/connect/fanvue' );
	}

	public static function handle_callback( $request ) {
		$connection = $request->get_param( 'fanvue_connection' );
		$creator_id = $request->get_param( 'creator_id' );
		$site_id    = $request->get_param( 'site_id' );
		$error      = $request->get_param( 'error' );

		if ( $error ) {
			Admin_Settings::set_last_error( 'Broker: ' . $error );
			wp_safe_redirect(
				admin_url( 'options-general.php?page=' . Admin_Settings::PAGE_SLUG . '&status=error' )
			);
			exit;
		}

		if ( $connection === 'success' && $creator_id && $site_id ) {
			$jwt = self::exchange_code_for_jwt( $site_id, $creator_id );
			if ( $jwt ) {
				self::store_jwt_token( $jwt );
				Admin_Settings::set_last_error( '' );
				wp_safe_redirect(
					admin_url( 'options-general.php?page=' . Admin_Settings::PAGE_SLUG . '&status=connected' )
				);
				exit;
			}
		}

		wp_safe_redirect(
			admin_url( 'options-general.php?page=' . Admin_Settings::PAGE_SLUG . '&status=pending' )
		);
		exit;
	}

	private static function exchange_code_for_jwt( $site_id, $creator_id ) {
		$response = wp_remote_post(
			self::get_broker_url() . '/api/internal/token',
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type' => 'application/json',
				],
				'body'    => wp_json_encode( [
					'site_id'    => $site_id,
					'creator_id' => $creator_id,
				] ),
			]
		);

		if ( is_wp_error( $response ) ) {
			Admin_Settings::set_last_error( 'Failed to exchange code: ' . $response->get_error_message() );
			return null;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code !== 200 ) {
			Admin_Settings::set_last_error( 'Token exchange failed: HTTP ' . $code );
			return null;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		return isset( $body['token'] ) ? $body['token'] : null;
	}

	private static function store_jwt_token( $token ) {
		$opts              = Admin_Settings::get_raw_options();
		if ( ! is_array( $opts ) ) {
			$opts = [];
		}
		$opts['jwt_token'] = Admin_Settings::encrypt_sensitive_value( $token );
		update_option( Admin_Settings::OPTION_NAME, $opts );
	}

	public static function disconnect() {
		$jwt = self::get_jwt_token();
		if ( ! $jwt ) {
			return false;
		}

		$site_id    = self::get_site_id();
		$creator_id = self::get_creator_id_from_jwt( $jwt );

		if ( ! $creator_id ) {
			self::clear_credentials();
			return true;
		}

		$response = wp_remote_post(
			self::get_broker_url() . '/oauth/disconnect',
			[
				'timeout' => 15,
				'headers' => [
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $jwt,
				],
				'body'    => wp_json_encode( [
					'site_id'    => $site_id,
					'creator_id' => $creator_id,
				] ),
			]
		);

		self::clear_credentials();
		return true;
	}

	private static function get_creator_id_from_jwt( $jwt ) {
		$parts = explode( '.', $jwt );
		if ( count( $parts ) !== 3 ) {
			return null;
		}

		$payload = json_decode( base64_decode( $parts[1] ), true );
		return isset( $payload['creator_id'] ) ? $payload['creator_id'] : null;
	}

	private static function clear_credentials() {
		$opts = Admin_Settings::get_raw_options();
		if ( ! is_array( $opts ) ) {
			$opts = [];
		}
		unset( $opts['jwt_token'] );
		update_option( Admin_Settings::OPTION_NAME, $opts );
	}

	public static function api_get( $endpoint, $args = [] ) {
		$jwt = self::get_jwt_token();
		if ( ! $jwt ) {
			return new \WP_Error( 'not_connected', 'Not connected to broker' );
		}

		$url = self::get_broker_url() . '/api/fanvue' . $endpoint;
		if ( ! empty( $args ) ) {
			$url = add_query_arg( $args, $url );
		}

		$response = wp_remote_get(
			$url,
			[
				'timeout' => 20,
				'headers' => [
					'Authorization'         => 'Bearer ' . $jwt,
					'X-Fanvue-API-Version' => self::get_fanvue_api_version(),
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code === 401 ) {
			self::clear_credentials();
			return new \WP_Error( 'token_expired', 'JWT token expired, please reconnect' );
		}

		if ( $code !== 200 ) {
			return new \WP_Error( 'api_error', 'API request failed: HTTP ' . $code );
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}

	public static function get_profile() {
		return self::api_get( '/profile' );
	}

	public static function get_subscribers( $page = 1, $size = 50 ) {
		return self::api_get( '/subscribers', [ 'page' => $page, 'size' => $size ] );
	}

	public static function get_followers( $page = 1, $size = 50 ) {
		return self::api_get( '/followers', [ 'page' => $page, 'size' => $size ] );
	}

	public static function get_status() {
		$site_id = self::get_site_id();
		if ( ! $site_id ) {
			return null;
		}

		$response = wp_remote_get(
			self::get_broker_url() . '/oauth/status/' . $site_id,
			[
				'timeout' => 10,
			]
		);

		if ( is_wp_error( $response ) ) {
			return null;
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}
}
